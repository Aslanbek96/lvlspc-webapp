import React from "react";

export default function EmployeePage() {
  return <div>EmployeePage</div>;
}
