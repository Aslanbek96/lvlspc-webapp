import React from "react";

export default function AdminPage() {
  return <div>Admin page</div>;
}
