import React from "react";
import CreateUserForm from "./components/create-user";

export default function CreateUserPage() {
  return (
    <div>
      <CreateUserForm />
    </div>
  );
}
